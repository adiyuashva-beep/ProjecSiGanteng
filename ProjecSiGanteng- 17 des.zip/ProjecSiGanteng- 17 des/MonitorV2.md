<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor Live - SiGanteng</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;700;900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        /* [Gaya CSS - TETAP PERTAHANKAN NUANSA DARK MODE GANTENG] */
        :root {
            --bg-dark: #0f172a;
            --card-bg: #1e293b;
            --neon-blue: #3b82f6;
            --neon-green: #10b981;
            --neon-red: #ef4444;
            --neon-gold: #f59e0b;
        }

        body { margin: 0; font-family: 'Outfit', sans-serif; background: var(--bg-dark); color: white; overflow: hidden; height: 100vh; display: flex; flex-direction: column; }
        
        /* HEADER MEWAH */
        .header {
            height: 10vh; background: rgba(30, 41, 59, 0.95); backdrop-filter: blur(10px);
            display: flex; justify-content: space-between; align-items: center; padding: 0 40px;
            border-bottom: 2px solid rgba(255,255,255,0.1);
            z-index: 10; box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .brand { display: flex; flex-direction: column; }
        .brand-row { display: flex; align-items: center; gap: 15px; }
        .brand h1 { 
            margin: 0; font-size: 2em; font-weight: 900; 
            background: linear-gradient(to right, #fff, #94a3b8); 
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; 
        }
        .badge-siganteng {
            background: rgba(59, 130, 246, 0.15);
            border: 2px solid var(--neon-blue); color: var(--neon-blue);
            padding: 2px 12px; border-radius: 8px;
            font-size: 0.8em; font-weight: 800; letter-spacing: 2px;
            text-shadow: 0 0 10px var(--neon-blue);
            animation: pulseGanteng 2s infinite;
        }
        .jam-digital { text-align: right; }
        .waktu { font-size: 2.8em; font-weight: 700; line-height: 1; color: #fff; font-variant-numeric: tabular-nums; }
        .tanggal { font-size: 1em; color: var(--neon-blue); font-weight: 600; text-transform: uppercase; }

        /* LAYOUT UTAMA 3 KOLOM */
        .main-content { flex: 1; display: flex; padding: 20px; gap: 20px; height: 80vh; overflow: hidden; }
        .card-box { background: var(--card-bg); border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 10px 20px rgba(0,0,0,0.2); }
        .card-header { padding: 12px; font-weight: 800; font-size: 1.1em; text-align: center; text-transform: uppercase; letter-spacing: 1px; display: flex; align-items: center; justify-content: center; gap: 10px; }
        
        /* KOLOM KIRI: GASIK */
        .col-gasik { flex: 1; border-top: 4px solid var(--neon-green); }
        .gasik-header { background: rgba(16, 185, 129, 0.1); color: var(--neon-green); }
        .list-container { flex: 1; overflow-y: auto; padding: 10px; scrollbar-width: none; }
        
        .rank-item { 
            display: flex; align-items: center; padding: 10px; margin-bottom: 6px;
            background: rgba(255,255,255,0.03); border-radius: 10px; transition: 0.3s;
        }
        .rank-num { width: 28px; height: 28px; background: #334155; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 800; margin-right: 10px; }
        .rank-1 { background: linear-gradient(90deg, rgba(245, 158, 11, 0.2), transparent); border: 1px solid rgba(245, 158, 11, 0.3); }
        .rank-1 .rank-num { background: var(--neon-gold); color: black; box-shadow: 0 0 15px var(--neon-gold); }
        .rank-2 .rank-num { background: #cbd5e1; color: black; }
        .rank-3 .rank-num { background: #b45309; color: white; }
        
        .rank-nama { font-weight: 600; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 0.9em; }
        .rank-jam { color: var(--neon-green); font-weight: 700; font-family: monospace; font-size: 1em; }

        /* KOLOM TENGAH: STATS & LIVE */
        .col-center { flex: 1.2; display: flex; flex-direction: column; gap: 20px; border: none; }
        
        .stats-wrapper { flex: 1.2; background: var(--card-bg); border-radius: 20px; padding: 15px; display: flex; flex-direction: column; align-items: center; justify-content: center; border: 1px solid rgba(255,255,255,0.05); position: relative; overflow: hidden; }
        /* Efek Glow Chart */
        .stats-wrapper::before { content:''; position:absolute; width:100%; height:100%; background: radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%); pointer-events: none; }

        .donut-chart { position: relative; width: 160px; height: 160px; border-radius: 50%; background: conic-gradient(var(--neon-blue) var(--p), #334155 0deg); display: flex; align-items: center; justify-content: center; margin-bottom: 15px; transition: 1s; box-shadow: 0 0 20px rgba(0,0,0,0.5); }
        .donut-inner { width: 85%; height: 85%; background: var(--card-bg); border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .big-percent { font-size: 2.2em; font-weight: 900; color: white; }
        
        .stat-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; width: 100%; gap: 10px; text-align: center; }
        .stat-item { background: rgba(255,255,255,0.03); padding: 10px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); }
        .stat-item h4 { margin: 0 0 5px 0; font-size: 0.75em; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px; }
        .stat-item p { margin: 0; font-size: 1.5em; font-weight: 700; }
        .c-hadir { color: var(--neon-green); text-shadow: 0 0 10px rgba(16, 185, 129, 0.4); } 
        .c-izin { color: var(--neon-gold); } 
        .c-alpha { color: var(--neon-red); }

        .live-box { flex: 1; background: var(--card-bg); border-radius: 20px; display: flex; flex-direction: column; overflow: hidden; border-top: 4px solid var(--neon-blue); }
        .live-header { padding: 12px; font-size: 0.9em; font-weight: 700; color: var(--neon-blue); border-bottom: 1px solid rgba(255,255,255,0.05); display:flex; align-items:center; gap:8px; background: rgba(59, 130, 246, 0.05); }
        .live-content { flex: 1; padding: 10px; display: flex; flex-direction: column; gap: 8px; overflow: hidden; }
        
        .live-card { background: rgba(255,255,255,0.03); padding: 10px; border-radius: 10px; display: flex; align-items: center; gap: 12px; animation: slideIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); border-left: 3px solid transparent; }
        .live-card.highlight { background: rgba(59, 130, 246, 0.1); border-left: 3px solid var(--neon-blue); box-shadow: 0 0 15px rgba(59, 130, 246, 0.2); }
        .avatar { width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2em; }

        /* KOLOM KANAN: TERLAMBAT & BELUM */
        .col-right-split { flex: 1; display: flex; flex-direction: column; gap: 20px; border:none; overflow: hidden; }
        
        .box-telat { 
            flex: 1; background: var(--card-bg); border-radius: 20px; 
            border: 2px solid rgba(239, 68, 68, 0.5); 
            display: flex; flex-direction: column; overflow: hidden;
            box-shadow: 0 0 15px rgba(239, 68, 68, 0.1);
        }
        .telat-header { 
            background: rgba(239, 68, 68, 0.2); color: var(--neon-red); padding: 12px; 
            font-weight: 800; font-size: 0.9em; text-align: center; display: flex; justify-content: center; gap:8px;
            animation: pulseRed 2s infinite;
        }
        
        .box-belum { 
            flex: 1.5; background: var(--card-bg); border-radius: 20px; 
            border-top: 4px solid #64748b; 
            display: flex; flex-direction: column; overflow: hidden;
        }
        .belum-header { background: rgba(100, 116, 139, 0.1); color: #94a3b8; padding: 12px; font-weight: 700; text-align: center; font-size: 0.9em; }

        .scroller-content { flex: 1; overflow: hidden; padding: 10px; position: relative; }
        .marquee-vertical { display: flex; flex-direction: column; gap: 6px; width: 100%; }
        /* Animasi Scroll Default */
        .anim-scroll { animation: scrollUp 20s linear infinite; } 
        /* Hover Stop */
        .scroller-content:hover .anim-scroll { animation-play-state: paused; }

        .alpha-row { 
            display: flex; justify-content: space-between; align-items: center;
            padding: 8px 12px; border-radius: 8px; background: rgba(255,255,255,0.02);
            border-bottom: 1px solid rgba(255,255,255,0.02);
        }
        .row-telat { background: rgba(239, 68, 68, 0.1); border-left: 3px solid var(--neon-red); }
        .row-belum { border-left: 3px solid #64748b; }
        
        .alpha-nama { font-weight: 600; font-size: 0.95em; color: #e2e8f0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 180px; }
        .alpha-kelas { font-size: 0.75em; color: #94a3b8; background: rgba(0,0,0,0.3); padding: 2px 6px; border-radius: 4px; display: inline-block; margin-top: 2px; }

        .footer-marquee { height: 5vh; background: #0f172a; display: flex; align-items: center; border-top: 1px solid rgba(255,255,255,0.1); z-index: 10; }
        marquee { font-size: 1.1em; font-weight: 600; color: #cbd5e1; letter-spacing: 1px; }

        @keyframes scrollUp { 0% { transform: translateY(0); } 100% { transform: translateY(-100%); } }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-20px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes pulseGanteng { 0% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7); } 70% { box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); } 100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); } }
        @keyframes pulseRed { 0% { background: rgba(239, 68, 68, 0.2); } 50% { background: rgba(239, 68, 68, 0.4); } 100% { background: rgba(239, 68, 68, 0.2); } }
        @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
    </style>
</head>
<body>

    <div class="header">
        <div class="brand">
            <div class="brand-row">
                <h1>SMAN 1 PEJAGOAN</h1>
                <span class="badge-siganteng">SI GANTENG</span>
            </div>
            <p id="typing-text" style="min-height: 1.2em; color:#94a3b8; font-weight:600; margin-top:5px; font-size: 0.9em;">PUSAT MONITORING KEDISIPLINAN</p>
        </div>
        <div class="jam-digital">
            <div class="waktu" id="jam-real">00:00</div>
            <div class="tanggal" id="tgl-real">...</div>
        </div>
    </div>

    <div class="main-content">
        
        <div class="card-box col-gasik">
            <div class="card-header gasik-header"><i class='bx bxs-trophy'></i> 10 SISWA TER-GASIK</div>
            <div class="list-container" id="gasik-list">
                <p style="text-align:center; padding:20px; opacity:0.5; font-size:0.9em;">Menunggu sang juara...</p>
            </div>
        </div>

        <div class="col-center">
            <div class="stats-wrapper">
                <div class="donut-chart" id="chart-absen" style="--p: 0deg;">
                    <div class="donut-inner">
                        <span class="big-percent" id="persen-text">0%</span>
                        <small style="color:#94a3b8; font-size:0.7em;">KEHADIRAN</small>
                    </div>
                </div>
                <div class="stat-grid">
                    <div class="stat-item"><h4 class="c-hadir">HADIR</h4><p id="total-hadir">0</p></div>
                    <div class="stat-item"><h4 class="c-izin">IZIN</h4><p id="total-izin">0</p></div>
                    <div class="stat-item"><h4 class="c-alpha">BELUM</h4><p id="total-alpha">0</p></div>
                </div>
            </div>

            <div class="live-box">
                <div class="live-header">
                    <span style="position:relative; display:flex; height:10px; width:10px; margin-right:5px;">
                      <span style="position:absolute; height:100%; width:100%; border-radius:50%; background:var(--neon-blue); opacity:0.75; animation:ping 1s cubic-bezier(0,0,0.2,1) infinite;"></span>
                      <span style="position:relative; height:10px; width:10px; border-radius:50%; background:var(--neon-blue);"></span>
                    </span>
                    BARU SAJA MASUK
                </div>
                <div id="live-container" class="live-content"></div>
            </div>
        </div>

        <div class="col-right-split">
            
            <div class="box-telat">
                <div class="telat-header">
                    <i class='bx bxs-alarm-exclamation'></i> TERLAMBAT (> 06:45)
                </div>
                <div class="scroller-content">
                    <div class="marquee-vertical" id="list-telat">
                        </div>
                </div>
            </div>

            <div class="box-belum">
                <div class="belum-header"><i class='bx bx-user-x'></i> BELUM HADIR</div>
                <div class="scroller-content">
                    <div class="marquee-vertical" id="list-belum">
                        </div>
                </div>
            </div>

        </div>
    </div>

    <div class="footer-marquee">
        <marquee scrollamount="8">
            📢 MONITORING REALTIME: DATA INI DITAMPILKAN LANGSUNG DARI SISTEM SI GANTENG. 🚀 "DISIPLIN ADALAH JEMBATAN ANTARA CITA-CITA DAN PENCAPAIAN." 🔥 BAGI SISWA YANG BELUM HADIR, DIMOHON SEGERA MENUJU SEKOLAH. TERIMA KASIH.
        </marquee>
    </div>

    <style>
        @keyframes ping { 75%, 100% { transform: scale(2); opacity: 0; } }
    </style>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
        import { getFirestore, collection, query, where, getDocs, onSnapshot, orderBy } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

        const firebaseConfig = {
            apiKey: "AIzaSyBXWR-_aJyoMrUjTeNQYlcPD8p3eu58yOo",
            authDomain: "siganteng-absensi.firebaseapp.com",
            databaseURL: "https://siganteng-absensi-default-rtdb.asia-southeast1.firebasedatabase.app",
            projectId: "siganteng-absensi",
            storageBucket: "siganteng-absensi.firebasestorage.app", 
            messagingSenderId: "917873420012",
            appId: "1:917873420012:web:0fe1a9eddc5f94959ba7c9"
        };

        const app = initializeApp(firebaseConfig);
        const db = getFirestore(app);

        // CONFIG
        const JAM_BATAS_TERLAMBAT = "06:45"; 
        const today = new Date().toLocaleDateString('fr-CA'); // YYYY-MM-DD
        
        let allSiswa = [];
        let dataAbsenHariIni = {};
        let totalSiswa = 0;

        // JAM REALTIME
        setInterval(() => {
            const now = new Date();
            document.getElementById('jam-real').innerText = now.toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'});
            document.getElementById('tgl-real').innerText = now.toLocaleDateString('id-ID', {weekday:'long', day:'numeric', month:'long'});
        }, 1000);

        // 1. LOAD DATA SISWA (BERSIH & CEPAT)
        async function loadAllSiswa() {
            try {
                const q = query(collection(db, "users"));
                const snap = await getDocs(q);
                
                // Set untuk filter ganda
                const nisnSet = new Set();
                allSiswa = [];

                snap.forEach(doc => {
                    const d = doc.data();
                    const nisnClean = String(d.username).replace(/[^a-zA-Z0-9]/g, ''); // Bersihkan ID
                    
                    if(!nisnSet.has(nisnClean)) {
                        nisnSet.add(nisnClean);
                        allSiswa.push({
                            username: nisnClean,
                            name: d.name || d.nama,
                            kelas: d.kelas
                        });
                    }
                });

                totalSiswa = allSiswa.length;
                console.log(`✅ ${totalSiswa} Siswa terdata.`);
                startMonitor(); 

            } catch (error) {
                console.error("Error Load Siswa:", error);
            }
        }

        // 2. MONITOR REALTIME
        function startMonitor() {
            const q = query(
                collection(db, "absensi"), 
                where("tanggal", "==", today),
                orderBy("waktu", "asc")
            );
            
            // LISTENER UTAMA
            onSnapshot(q, (snapshot) => {
                let tempAbsen = {};
                
                snapshot.forEach(doc => {
                    const d = doc.data();
                    const nisnClean = String(d.nisn).replace(/[^a-zA-Z0-9]/g, '');
                    const jamFix = d.jam_masuk ? new Date(d.jam_masuk.seconds * 1000).toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'}) : '-';
                    
                    tempAbsen[nisnClean] = { ...d, jam_display: jamFix };
                });
                
                dataAbsenHariIni = tempAbsen;
                updateUI();
            });

            // LIVE FEED LISTENER (Untuk efek blink "Baru Masuk")
            snapshot.docChanges().forEach((change) => {
                if (change.type === "added") {
                    const val = change.doc.data();
                    // Pastikan bukan load awal (cek timestamp dekat waktu sekarang)
                    // Tapi untuk demo, kita tampilkan saja semua yang masuk stream
                    const jamFix = val.jam_masuk ? new Date(val.jam_masuk.seconds * 1000).toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'}) : '-';
                    
                    if (val.status_terakhir === 'Masuk' || val.status_terakhir === 'Terlambat') {
                        addToFeed({
                            name: val.nama,
                            kelas: val.kelas,
                            jam: jamFix,
                            status: val.status_terakhir
                        });
                    }
                }
            });
        }

        function updateUI() {
            const absenArr = Object.values(dataAbsenHariIni);
            
            // Filter Data
            const listHadir = absenArr.filter(d => d.status_terakhir === 'Masuk' || d.status_terakhir === 'Terlambat');
            const listIzin = absenArr.filter(d => d.status_terakhir === 'Izin' || d.status_terakhir === 'Sakit' || d.status_terakhir === 'Izin Keluar');
            
            // Sortir Gasik & Telat
            const listGasik = listHadir.filter(d => d.jam_display <= JAM_BATAS_TERLAMBAT).sort((a,b) => a.jam_display.localeCompare(b.jam_display));
            const listTelat = listHadir.filter(d => d.jam_display > JAM_BATAS_TERLAMBAT).sort((a,b) => b.jam_display.localeCompare(a.jam_display)); // Yang baru telat di atas
            
            // Hitung Belum Hadir
            const nisnHadir = Object.keys(dataAbsenHariIni);
            const listBelum = allSiswa.filter(s => !nisnHadir.includes(s.username)).sort((a,b) => a.kelas.localeCompare(b.kelas));

            // RENDER UI
            renderGasik(listGasik.slice(0, 10)); // Top 10
            renderScrollList(listTelat, 'list-telat', 'telat');
            renderScrollList(listBelum, 'list-belum', 'belum');

            // STATISTIK
            const totHadir = listHadir.length;
            const totIzin = listIzin.length;
            const totAlpha = totalSiswa - (totHadir + totIzin);

            document.getElementById('total-hadir').innerText = totHadir;
            document.getElementById('total-izin').innerText = totIzin;
            document.getElementById('total-alpha').innerText = totAlpha < 0 ? 0 : totAlpha;

            // Chart
            const persen = totalSiswa > 0 ? Math.round((totHadir/totalSiswa)*100) : 0;
            document.getElementById('persen-text').innerText = persen + "%";
            const deg = persen * 3.6;
            document.getElementById('chart-absen').style.setProperty('--p', `${deg}deg`);
        }

        function renderScrollList(data, id, type) {
            const container = document.getElementById(id);
            container.innerHTML = '';
            
            if(data.length === 0) {
                container.innerHTML = `<div style="text-align:center; padding:20px; color:#64748b; font-style:italic;">${type==='telat'?'Tidak ada yang terlambat.':'Semua siswa hadir!'}</div>`;
                return;
            }

            // ATUR KECEPATAN SCROLL OTOMATIS
            // Semakin banyak data, semakin cepat sedikit biar gak nunggu lama
            // Base: 20 detik. Tiap 10 siswa nambah durasi dikit biar bisa kebaca.
            let durasi = data.length < 5 ? 0 : (data.length * 2.5); // Detik
            if(durasi > 0) {
                container.style.animation = `scrollUp ${durasi}s linear infinite`;
            } else {
                container.style.animation = 'none';
            }

            data.forEach(d => {
                const jam = d.jam_display || '';
                const nama = d.name || d.nama;
                const rowClass = type === 'telat' ? 'row-telat' : 'row-belum';
                const jamHtml = type === 'telat' ? `<span style="color:var(--neon-red); font-weight:bold;">${jam}</span>` : '';
                
                const html = `
                    <div class="alpha-row ${rowClass}">
                        <div style="flex:1; overflow:hidden;">
                            <div class="alpha-nama">${nama}</div>
                            <div class="alpha-kelas">${d.kelas}</div>
                        </div>
                        <div>${jamHtml}</div>
                    </div>`;
                container.insertAdjacentHTML('beforeend', html);
            });
            
            // DUPLIKASI DATA JIKA SEDIKIT (Biar Marquee mulus tidak putus)
            if(data.length > 5 && data.length < 15) {
                 container.innerHTML += container.innerHTML; 
            }
        }

        function renderGasik(data) {
            const el = document.getElementById('gasik-list');
            el.innerHTML = '';
            if(data.length===0) { el.innerHTML = '<p style="text-align:center; padding:20px; opacity:0.5;">Belum ada data.</p>'; return;}
            
            data.forEach((d, i) => {
                let cls = i===0 ? 'rank-1' : (i===1 ? 'rank-2' : (i===2 ? 'rank-3' : ''));
                const html = `
                    <div class="rank-item ${cls}">
                        <div class="rank-num">${i+1}</div>
                        <div class="rank-nama">${d.nama}<br><span style="font-size:0.75em; opacity:0.7; font-weight:normal;">${d.kelas}</span></div>
                        <div class="rank-jam">${d.jam_display}</div>
                    </div>`;
                el.insertAdjacentHTML('beforeend', html);
            });
        }

        function addToFeed(d) {
            const con = document.getElementById('live-container');
            const icon = d.status === 'Terlambat' ? "<i class='bx bxs-alarm-exclamation'></i>" : "<i class='bx bxs-user-check'></i>";
            const color = d.status === 'Terlambat' ? 'var(--neon-red)' : 'var(--neon-green)';
            
            const html = `
                <div class="live-card highlight">
                    <div class="avatar" style="color:${color}; background:rgba(255,255,255,0.1);">${icon}</div>
                    <div style="flex:1;">
                        <div style="font-weight:700; font-size:0.9em;">${d.name}</div>
                        <div style="font-size:0.7em; opacity:0.7;">${d.kelas}</div>
                    </div>
                    <div style="font-weight:800; color:${color}; font-size:0.9em;">${d.jam}</div>
                </div>`;
            con.insertAdjacentHTML('afterbegin', html);
            if(con.children.length > 6) con.lastElementChild.remove();
            setTimeout(() => { if(con.firstElementChild) con.firstElementChild.classList.remove('highlight'); }, 2000);
        }

        // TYPING EFFECT
        const texts = ["PUSAT MONITORING KEDISIPLINAN", "DISIPLIN ADALAH KUNCI KESUKSESAN", "MEMBANGUN GENERASI EMAS", "SMAN 1 PEJAGOAN JUARA!"];
        let count=0, index=0, currentText="", letter="", isDeleting=false;
        function type() {
            if(count === texts.length) count=0;
            currentText = texts[count];
            if(isDeleting) letter = currentText.slice(0, --index);
            else letter = currentText.slice(0, ++index);
            
            const target = document.getElementById("typing-text");
            if(target) target.innerHTML = letter + '<span style="border-right: 3px solid var(--neon-blue); animation: blink 0.7s infinite;">&nbsp;</span>';

            let typeSpeed = isDeleting ? 30 : 80;
            if(!isDeleting && letter.length === currentText.length) { typeSpeed = 2000; isDeleting = true; }
            else if(isDeleting && letter.length === 0) { isDeleting = false; count++; typeSpeed = 500; }
            setTimeout(type, typeSpeed);
        }
        document.addEventListener("DOMContentLoaded", type);

        // START
        loadAllSiswa();
    </script>
</body>
</html>